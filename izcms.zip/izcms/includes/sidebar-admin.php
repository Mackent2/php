<div id="container">
	<aside class="sidebar-a">
		<ul>
			<li><a href="">Home</a></li>
			<li><a href="add-pages.php"<?php here_page('add-pages.php'); ?>>Add Pages</a></li>
			<li><a href="view-pages.php" <?php here_page('view-pages.php'); ?>>View Pages</a></li>
			<li><a href="add-categories.php" <?php here_page('add-categories.php'); ?>>Add Categories</a></li>
			<li><a href="view-categories.php" <?php here_page('view-categories.php'); ?>>View Categories</a></li>
			<li><a href="manage_users.php" <?php here_page('manage_users.php'); ?>>Manage Users</a></li>		
		</ul>
	</aside>