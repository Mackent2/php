<?php include ('header.php');?>
<?php include ('mysqli_connect.php');?>
<?php include ('functions.php');?>
<?php include ('sidebar-a.php');?>
<section>
	<h3>Welcome to IzCMS</h3>
	
</section>
<?php include ('sidebar-b.php');?>
<?php include ('footer.php');?>

