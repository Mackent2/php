	<aside class="sidebar-b">
		<h3>Chào mừng bạn</h3>
		Sáng 1/5, lúc ánh bình minh đang dần ló dạng, ông Nguyễn Xuân Anh - Bí thư Thành ủy TP.Đà Nẵng và ông Huỳnh Đức Thơ - Chủ tịch UBND TP.Đà Nẵng đã hòa mình vào làn nước mát lạnh tại một bãi biển thuộc quận Sơn Trà.
	</aside>
</div>