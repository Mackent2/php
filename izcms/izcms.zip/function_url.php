<?php
		define('URL', 'http://localhost/project/izcms/');
	//Kiem tra ket qua tra ve co dung hay khong
?>